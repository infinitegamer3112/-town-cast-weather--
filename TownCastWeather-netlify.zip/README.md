# TownCast Weather

Small no-build weather app with:

- live temperature and wind speeds
- 12-hour forecast
- zoomable rain radar
- snow-highlight radar mode
- smooth temperature heatmap mode
- live lightning map mode
- "use my location" support
- shareable town links

## Run it locally

Open PowerShell in this folder and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\serve-local.ps1
```

Then open:

```text
http://localhost:8080
```

## Deploy It Publicly

This is a static site, so you can host it on Netlify or GitHub Pages without a build step.

### Netlify

1. Put this folder in a Git repo and push it to GitHub.
2. In Netlify, create a new site from that repo.
3. Leave the publish directory as the project root.
4. Deploy.

The included [netlify.toml](C:/Users/micha/OneDrive/Documents/New%20project/netlify.toml) is already set up for this.

### GitHub Pages

1. Push this project to a GitHub repo with a `main` branch.
2. In the repo settings, enable GitHub Pages and set the source to GitHub Actions.
3. Push again or run the workflow manually.

The included workflow at [.github/workflows/deploy-pages.yml](C:/Users/micha/OneDrive/Documents/New%20project/.github/workflows/deploy-pages.yml) will publish the site for you.

## Sharing

- `localhost` links only work on your own device.
- Once deployed, the app automatically builds public share links from the live site URL.

## Notes

- Browsers usually require `localhost` or `https` for location sharing.
- Weather data is loaded client-side from Open-Meteo.
- Radar frames are loaded client-side from RainViewer.
